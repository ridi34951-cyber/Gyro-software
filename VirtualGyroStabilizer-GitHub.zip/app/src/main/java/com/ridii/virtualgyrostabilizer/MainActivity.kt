package com.ridii.virtualgyrostabilizer

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.os.SystemClock
import android.provider.MediaStore
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors
import kotlin.math.PI

class MainActivity : ComponentActivity(), SensorEventListener {
    private lateinit var preview: PreviewView
    private lateinit var status: TextView
    private lateinit var record: Button
    private lateinit var strength: SeekBar
    private lateinit var sensors: SensorManager
    private var recording: Recording? = null
    private var videoCapture: VideoCapture<Recorder>? = null

    private val gravity = FloatArray(3)
    private val magnetic = FloatArray(3)
    private var haveG = false
    private var haveM = false
    private var last = DoubleArray(3)
    private var lastTime = 0L
    private var virtualRate = DoubleArray(3)
    private val executor = Executors.newSingleThreadExecutor()

    private val permissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result[Manifest.permission.CAMERA] == true) startCamera()
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        setContentView(R.layout.activity_main)
        preview = findViewById(R.id.preview)
        status = findViewById(R.id.status)
        record = findViewById(R.id.record)
        strength = findViewById(R.id.strength)
        sensors = getSystemService(SENSOR_SERVICE) as SensorManager

        val p = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (android.os.Build.VERSION.SDK_INT <= 28) p.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (p.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) {
            startCamera()
        } else permissions.launch(p.toTypedArray())

        record.setOnClickListener { if (recording == null) startRecording() else stopRecording() }
    }

    override fun onResume() {
        super.onResume()
        val a = sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val m = sensors.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        if (a != null) sensors.registerListener(this, a, SensorManager.SENSOR_DELAY_GAME)
        if (m != null) sensors.registerListener(this, m, SensorManager.SENSOR_DELAY_GAME)
        status.text = if (sensors.getDefaultSensor(Sensor.TYPE_GYROSCOPE) == null)
            "VIRTUAL GYRO • accel + magnetometer"
        else "GYRO HARDWARE TERDETEKSI • virtual fallback siap"
    }

    override fun onPause() { sensors.unregisterListener(this); super.onPause() }

    override fun onDestroy() { recording?.stop(); executor.shutdown(); super.onDestroy() }

    override fun onSensorChanged(e: SensorEvent) {
        when (e.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> {
                val k = .85f
                for (i in 0..2) gravity[i] = k * gravity[i] + (1-k) * e.values[i]
                haveG = true
            }
            Sensor.TYPE_MAGNETIC_FIELD -> {
                val k = .85f
                for (i in 0..2) magnetic[i] = k * magnetic[i] + (1-k) * e.values[i]
                haveM = true
            }
        }
        if (!haveG || !haveM) return
        val r = FloatArray(9); val i = FloatArray(9)
        if (!SensorManager.getRotationMatrix(r, i, gravity, magnetic)) return
        val o = FloatArray(3)
        SensorManager.getOrientation(r, o)
        val now = SystemClock.elapsedRealtimeNanos()
        if (lastTime != 0L) {
            val dt = (now - lastTime) / 1e9
            if (dt > 0 && dt < .2) for (n in 0..2) virtualRate[n] = delta(o[n].toDouble(), last[n]) / dt
        }
        for (n in 0..2) last[n] = o[n].toDouble()
        lastTime = now
    }

    private fun delta(a: Double, b: Double): Double {
        var d = a - b
        while (d > PI) d -= 2*PI
        while (d < -PI) d += 2*PI
        return d
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val p = Preview.Builder().build().also { it.surfaceProvider = preview.surfaceProvider }
            val rec = Recorder.Builder()
                .setQualitySelector(QualitySelector.fromOrderedList(listOf(Quality.FHD, Quality.HD, Quality.SD)))
                .build()
            videoCapture = VideoCapture.withOutput(rec)
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, p, videoCapture)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun startRecording() {
        val capture = videoCapture ?: return
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "VirtualGyro_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (android.os.Build.VERSION.SDK_INT >= 29)
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/VirtualGyro")
        }
        val output = MediaStoreOutputOptions.Builder(
            contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(values).build()

        recording = capture.output.prepareRecording(this, output).withAudioEnabled()
            .start(ContextCompat.getMainExecutor(this)) { event ->
                when (event) {
                    is VideoRecordEvent.Start -> {
                        record.text = "STOP"
                        status.text = "REKAM • virtual gyro aktif"
                    }
                    is VideoRecordEvent.Finalize -> {
                        record.text = "REKAM"
                        recording = null
                        status.text = if (event.hasError()) "Gagal: ${event.error}"
                        else "Video tersimpan • sensor virtual aktif"
                    }
                }
            }
    }

    private fun stopRecording() { recording?.stop(); recording = null; record.text = "REKAM" }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
