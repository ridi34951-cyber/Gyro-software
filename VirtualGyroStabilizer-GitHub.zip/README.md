# Virtual Gyro Stabilizer

Android camera project with a software/virtual gyro foundation.

## Prinsip

Accelerometer + magnetometer -> estimasi orientasi -> perubahan orientasi terhadap waktu -> angular velocity / virtual gyro.

## Build otomatis lewat GitHub

1. Buat repository baru di GitHub.
2. Upload seluruh isi ZIP ini ke repository (bukan file ZIP-nya).
3. Pastikan folder `.github/workflows/build.yml` ikut ter-upload.
4. Buka tab **Actions**.
5. Pilih workflow **Build APK**.
6. Tekan **Run workflow**.
7. Setelah selesai, buka hasil workflow dan bagian **Artifacts**.
8. Download `VirtualGyroStabilizer-debug`.
9. Extract ZIP artifact tersebut dan install `app-debug.apk`.

Workflow juga otomatis berjalan setiap kali ada push ke branch `main` atau `master`.

## Catatan teknis

Versi ini adalah fondasi sensor + kamera. Ia menghitung virtual gyro dari accelerometer dan magnetometer, tetapi belum melakukan full frame-by-frame video stabilization (decode -> transform/crop -> encode -> mux). Jadi APK hasil build belum boleh dianggap sebagai EIS penuh.

Virtual gyro dari sensor non-gyro tidak identik dengan gyro MEMS dan dapat drift/noisy ketika terjadi translasi atau gerakan cepat.

## Requirements

- Android Studio/Gradle tidak diperlukan di sisi HP untuk GitHub Actions.
- GitHub Actions menyediakan environment build.
- APK debug tidak ditandatangani untuk distribusi Play Store; untuk instalasi pribadi biasanya cukup.
